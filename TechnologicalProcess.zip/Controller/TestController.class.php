<?php

namespace Home\Controller;
use Think\Controller;
use Think\Model;
class TestController extends Controller {
  //还原模式是否开启
  public $ac=0;
  public $acTime=0;
  //流程参数
  public function run(){
    //引入文件
    $this->data=require dirname(__FILE__).'/Code/Test/demo.php';
    if($this->data['session']){
      $sesskey=array_keys($this->data['session']);
      foreach ($sesskey as $v){
        session('b_'.$v,session($v));
        session($v,$this->data['session'][$v]);
      }
    }
    $Avs=$this->analysisFile();

    $chartUnit=$this->analysisFunction($Avs);
    if($this->data['session']){
      foreach ($sesskey as $v){
        session($v,session('b_'.$v));
        session('b_'.$v,null);
      }
    }
    echo '功能名：'.$this->data['unit'];
    dump($chartUnit,true,'',false);
    
  }
 
  //byte
  public function format_bytes($size) { 
    $units = array(' B', ' KB', ' MB', ' GB', ' TB'); 
    for ($i = 0; $size >= 1024 && $i < 4; $i++) $size /= 1024; 
    return round($size, 2).$units[$i]; 
  }
  //解析类名
  private function analysisFile(){
    //解析类名
    $Ac=array_keys($this->data['Action']);
    foreach($Ac as $k=>$v){
      $unique=explode('|unit|', $v);
      $Ac[$unique[0]]=array('action'=>$unique[0],'event'=>$unique[2]);
      unset($Ac[$k]);
    }
    //加载所需类
    $Avs=array();
    foreach($Ac as $v){
      if($v['event']){
  
        $Avs[$v['action']]=A($v['action'],$v['event']);
      }else{
        $Avs[$v['action']]=A($v['action']);
      }
    }
    return $Avs;
  }
  //加载方法
  private function analysisFunction($Avs){
    //参数链
    $auto=array();
    $ks=0;
    //输入输出数据参数报表
    $chartUnit=array();
    $unit='';
    //方法实现
    foreach($this->data['Action'] as $k=>$v){
      $ks++;
      $unit=explode('|unit|', $k);
      if(in_array('auto', $v,true)){
        $chartUnit['类:'.$unit[0].'函数:'.$unit[1]]['input']=$x;
        $auto[$ks]['input']=$x;
        if($v[1]=='array'){
          $x=array($x);
        }
        $x=call_user_func_array(array($Avs[$unit[0]], $unit[1]), $x);
      }else
      if($v['auto']){

        $auto[$ks]['input']=$x;
        $arr=array();
          
        foreach($v['auto'] as $m=>$h){
          if(is_array($h)){
            foreach($h as $p){
              $arr[]=$auto[$p][$m];
            }
          }else{
            $arr[]=$auto[$h][$m];
          }
          
        }
        $chartUnit['类:'.$unit[0].'函数:'.$unit[1]]['input']=$arr;
        $x=call_user_func_array(array($Avs[$unit[0]], $unit[1]),$arr);
      }
      else{
        $auto[$ks]['input']=$v;
        $chartUnit['类:'.$unit[0].'函数:'.$unit[1]]['input']=$v;
        if(is_array($v)){
          $x=call_user_func_array(array($Avs[$unit[0]], $unit[1]), $v);

        }else{
          $x=$Avs[$unit[0]]->$unit[1]();
        }
        
      }
       $auto[$ks]['output']=$x;
      $chartUnit['类:'.$unit[0].'函数:'.$unit[1]]['output']=$x;
    }
    return $chartUnit;
  }
  public function _action(){
    if($this->ac===0){
      $this->ac=memory_get_usage();
      $this->acTime=microtime(true);
    }
    $bc=memory_get_usage()-$this->ac;
    $tc=microtime(true);
    $bcTime=$tc-$this->acTime;
    $this->acTime=$tc;
    echo '内存：'.$this->format_bytes($bc);
    echo '时间：'.round($bcTime, 4);
    echo '<hr>';
  }

}

?>