<?php

namespace Home\Controller;
use Think\Controller;
class Index1Controller extends Controller {
 
  public function page($a=0,$b=0,$c=0){
    $a++;
    $b++;
    $c++;
    $d=array($a,$b,$c);
    return $d;
  }
}

?>