<?php
return array(
        'unit'=>'Action',
        'Action'=>array(
        //Index|unit|index|unit|Event支持event里使用
        //auto有两个写法 auto 或者  auto,array
        //auto:只用auto的话会将上次返回的多为数组当作多个参数
        //auto,array:会将上次返回的多维数组当作一个参数里的多个数组
        //向上查找指定方法的返回值或者输入值带入auto里
          'Index|unit|index'=>array(10,23,-30),
          
          'Index1|unit|page'=>array('auto'),
          'Index|unit|ins'=>array(1,2),
          
          'Index|unit|index2'=>array(
              'auto'=>array(
                'input'=>2,'output'=>array(3,1),
                )
              ),
        ),
    );