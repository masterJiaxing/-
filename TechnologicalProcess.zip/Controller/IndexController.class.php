<?php

namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
 
  public function index($a=0,$b=0,$c=0){
    $a++;
    $b++;
    $c++;
    $d=array($a,$b,$c);
    return $d;
  }
  public function index2($a=0,$b=0,$c){
   
    foreach($a as &$v){
      $v++;
    }
    foreach($b as &$v){
      $v++;
    }
    foreach($c as &$v){
      $v++;
    }
    $d=array($a,$b,$c);
    return $d;
  }
  public function ins($a=0,$b=0){
    $a++;
    $b++;
    $c=array($a,$b);
    return $c;
  }
}

?>